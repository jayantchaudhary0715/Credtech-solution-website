# Changelog

Every change to the Credtech Solutions website is recorded here, newest first. After each change the project is rebuilt (`npm run build`) and the whole folder is synced to `Desktop/Credtech`.

## 18 October 2026

### Every page: an interactive set piece
Each page now has its own moving piece of “Credtech City”, in the spirit of the Services page Ferris wheel and train. All of them work with keyboard and touch, rest when off screen, hold still for visitors with reduced motion, and show their full content without JavaScript.

| Page | Set piece |
| --- | --- |
| About | **Elevator in UrbTech Tower.** As you scroll, a lift climbs one floor for each part of the story; the doors open on each floor and the matching card lights up. The growth figures roll up like odometers. |
| Service pages (8) | **Metro line.** A sticky route map of the sections on the page; a small train moves to the stop you are reading and passed stops turn blue. Horizontal under the header on tablets and phones. |
| Campaigns | **Billboard tower.** The posters revolve on a 3D tower. Drag or swipe to spin it, use the arrows, or pause it; the poster at the front is named below and links to its campaign. Tabbing to a poster turns it to the front. |
| Case studies (4) | **Odometers.** The published figures (for example 43M+ reach) roll into place when they scroll into view. |
| Clients | **Logo orbit.** Twelve client logos circle the Credtech planet on two rings; logos with a client story link to it. Hover or focus pauses the orbit. |
| Plans | **Skyline.** Basic, Silver and Gold become three towers that build floor by floor (one floor per feature, with the exact prices on each sign). Clicking a tower jumps to that plan and highlights it. |
| Blog | **LED news ticker** with the latest article titles. Pauses on hover. |
| Blog posts (4) | **Reading rocket.** A rocket climbs a progress line as you read and shows the percentage; posts now show an estimated reading time. |
| Contact | **Signal tower.** The signal bars fill as the form is completed and the tower sends a pulse for each finished field. |
| Schedule a Meeting | **Split flap departures board** with a live clock; the rows flip in letter by letter. |
| Careers | **Hot air balloons**, one per open role. Picking one chooses that role in the application form and takes you to it. |
| Privacy Policy | **Vault door** whose dial turns as you read the policy. |
| 404 | **Lost train** whose coaches are the way back: Home, Services, Campaigns, Contact. |

* No new statistics or claims were added. Figures come from the existing content files; the departures board statuses are decorative labels.
* Fixed: a broad `.stat span` style was resizing nested spans; it now targets only the label.
* Files: new `src/templates/fun.mjs` (all set pieces), `src/templates/pages.mjs`, `src/templates/components.mjs` (`pageHero` takes a `visual`), `src/styles.css`, `src/site.js`, `content/pages.json` (`schedule.board`).

### Services page: specialist services train
* The “More ways we help” grid is now a train. A blue locomotive with the CredTech mark and a headlight pulls one coach per specialist service (7 coaches) along a lit track.
* The train loops slowly from right to left at about 30 px per second. It starts with the engine in view, stops while the pointer is over it, and has a Pause/Play button.
* Visitors with reduced motion turned on get a still train they can scroll sideways.
* Fixed a style clash: the train track no longer shares the `.track` class with the client logo strip.
* Files: `src/templates/components.mjs` (`serviceTrain`), `src/templates/pages.mjs`, `src/styles.css`, `src/site.js`.

### Services page: 3D Ferris wheel
* The service cards now ride on a 3D Ferris wheel. Every 3.2 seconds the wheel turns one cabin: the next service reaches the bottom (“Now boarding”) and the previous one rises up the right side. Cabins stay upright and swing slightly as the wheel moves.
* A side panel shows the boarding service (number, description, link) with previous, pause and next buttons. The wheel pauses on hover and keyboard focus; hovering a cabin previews it in the panel; clicking a cabin opens the service.
* Tablets and phones: wheel above the panel, scaled to fit; on phones the cabins show images only.
* Reduced motion: the wheel starts paused and steps without animation.
* Files: `src/templates/components.mjs` (`ferrisWheel`), `src/templates/pages.mjs`, `src/styles.css`, `src/site.js`.

### Logo in brand colours
* The C/T mark in the header and footer logo now uses the brand blue (#5878F8) and cyan (#08D0E8) from the live ct-logo. The CredTech wordmark stays white, as on the live site.
* New file `assets/img/brand/logo.png` replaces `logo-white.png`. The social preview image was regenerated with the new logo.

## 17 October 2026

### First build
* 28-page static site built from the Claude 3D prototype with content migrated from credtechsolutions.com (24 pages and 6 posts read through the WordPress REST API).
* Pages: Home (3D city), About, Services, 8 service pages, Campaigns, 4 case studies, Clients, Plans, Blog with 4 posts, Contact, Schedule a Meeting, Careers, Privacy Policy, 404.
* Content in `content/*.json` with source URLs; 109 optimised WebP images; three.js 0.160.0 bundled locally.
* SEO: titles, descriptions, canonical URLs, Open Graph, JSON-LD, sitemap, robots, 301 redirects from old WordPress URLs.
* Forms validate and only report success on a real 2xx response; no form endpoint is configured yet.
* Removed the Harikatha YouTube list after finding every video is a Freedom at Midnight review (kept hidden on the Freedom at Midnight record).
* Carried over the Google Search Console verification tag.
* Content questions and setup tasks are listed in `DELIVERY-NOTES.md`.
