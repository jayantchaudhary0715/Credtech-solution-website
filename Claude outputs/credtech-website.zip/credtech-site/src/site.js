/* Credtech Solutions: page UI shared by every page (no 3D). */
(function () {
  'use strict';
  var cfgEl = document.getElementById('site-config');
  var CFG = {};
  try { CFG = JSON.parse(cfgEl ? cfgEl.textContent : '{}'); } catch (e) { CFG = {}; }
  var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return [].slice.call((r || document).querySelectorAll(s)); };

  /* ---------- mobile menu ---------- */
  var mBtn = $('.menu-btn'), menu = $('#menu');
  if (mBtn && menu) {
    var setMenu = function (open) {
      menu.classList.toggle('open', open);
      mBtn.setAttribute('aria-expanded', String(open));
      mBtn.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
      if (open) { var f = menu.querySelector('a'); if (f) f.focus(); }
    };
    mBtn.addEventListener('click', function () { setMenu(!menu.classList.contains('open')); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && menu.classList.contains('open')) { setMenu(false); mBtn.focus(); } });
    document.addEventListener('click', function (e) { if (menu.classList.contains('open') && !menu.contains(e.target) && !mBtn.contains(e.target)) setMenu(false); });
    $$('a', menu).forEach(function (a) { a.addEventListener('click', function () { setMenu(false); }); });
  }

  /* ---------- scroll progress + journey rail (homepage) ---------- */
  var bar = $('#progress'), secs = $$('[data-stop]'), rail = $$('.rail a');
  if (bar || rail.length) {
    var onScroll = function () {
      if (rail.length) {
        var y = scrollY + innerHeight * 0.5, i = 0;
        secs.forEach(function (s, k) { if (s.offsetTop <= y) i = k; });
        rail.forEach(function (a, k) { a.classList.toggle('on', k === i); if (k === i) a.setAttribute('aria-current', 'step'); else a.removeAttribute('aria-current'); });
        var hud = document.getElementById('hud'); if (hud) hud.style.opacity = i >= secs.length - 1 ? '0' : '';
      }
      if (bar) { var max = document.documentElement.scrollHeight - innerHeight; bar.style.width = (max > 0 ? scrollY / max * 100 : 0) + '%'; }
    };
    addEventListener('scroll', onScroll, { passive: true }); addEventListener('resize', onScroll); onScroll();
  }

  /* ---------- campaign strip ---------- */
  var strip = $('#strip');
  if (strip) {
    var by = function (d) { strip.scrollBy({ left: d * strip.clientWidth * 0.8, behavior: reduce ? 'auto' : 'smooth' }); };
    var p = $('#prev'), n = $('#next');
    if (p) p.addEventListener('click', function () { by(-1); });
    if (n) n.addEventListener('click', function () { by(1); });
  }
  if (!reduce && window.matchMedia && matchMedia('(hover: hover)').matches) {
    $$('.film').forEach(function (f) {
      var c = f.querySelector('.card');
      f.addEventListener('pointermove', function (e) {
        var r = f.getBoundingClientRect(), x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
        c.style.transform = 'rotateY(' + ((x - 0.5) * 16) + 'deg) rotateX(' + ((0.5 - y) * 14) + 'deg) translateZ(10px)';
        c.style.setProperty('--mx', x * 100 + '%'); c.style.setProperty('--my', y * 100 + '%');
      });
      f.addEventListener('pointerleave', function () { c.style.transform = ''; });
    });
  }
  window.__flash = function (sel) {
    var el = document.querySelector(sel); if (!el) return;
    el.classList.add('flash'); setTimeout(function () { el.classList.remove('flash'); }, 1800);
  };

  /* ---------- services Ferris wheel ---------- */
  var fw = $('.fw');
  if (fw) {
    var stage = $('#fw-stage'), rotor = $('#fw-rotor'), cabs = $$('.fw-cab', fw), N = cabs.length, slot = 360 / N;
    var step = 0, playing = !reduce, held = false, inView = true;
    var fwTitle = $('#fw-title'), fwText = $('#fw-text'), fwLink = $('#fw-link'), fwNum = $('#fw-num'), fwPlay = $('#fw-play');
    var fit = function () {
      var s = Math.min(1, stage.clientWidth / 820);
      stage.style.setProperty('--s', s); stage.style.height = Math.round(920 * s) + 'px';
      fw.classList.toggle('compact', s < 0.66);
    };
    var show = function (i) {
      cabs.forEach(function (c, k) { c.classList.toggle('on', k === i); });
      var a = cabs[i].querySelector('.fw-card');
      fwTitle.textContent = a.getAttribute('data-title');
      fwText.textContent = a.getAttribute('data-text');
      fwLink.setAttribute('href', a.getAttribute('href'));
      fwLink.textContent = a.getAttribute('data-cta') + ' →';
      fwNum.textContent = (i + 1 < 10 ? '0' : '') + (i + 1);
    };
    var current = function () { return ((step % N) + N) % N; };
    var apply = function () {
      var rot = -step * slot;
      rotor.style.transform = 'rotate(' + rot + 'deg)';
      cabs.forEach(function (c, k) { c.firstElementChild.style.transform = 'rotate(' + (-(k * slot + rot)) + 'deg)'; });
    };
    var sway = function () {
      if (reduce) return;
      $$('.fw-swing', fw).forEach(function (s) { s.classList.remove('sway'); void s.offsetWidth; s.classList.add('sway'); });
    };
    // Turn one cabin: the next service arrives at the bottom, the last one rises up the right side.
    var go = function (d) { step += d; apply(); sway(); show(current()); };
    var setPlay = function (on) {
      playing = on;
      fwPlay.textContent = on ? 'Pause' : 'Play';
      fwPlay.setAttribute('aria-pressed', String(!on));
      fwPlay.setAttribute('aria-label', on ? 'Pause the wheel' : 'Play the wheel');
    };
    setPlay(playing);
    fit(); addEventListener('resize', fit);
    $('#fw-prev').addEventListener('click', function () { go(-1); });
    $('#fw-next').addEventListener('click', function () { go(1); });
    fwPlay.addEventListener('click', function () { setPlay(!playing); });
    stage.addEventListener('mouseenter', function () { held = true; });
    stage.addEventListener('mouseleave', function () { held = false; show(current()); });
    cabs.forEach(function (c, k) {
      var a = c.querySelector('.fw-card');
      a.addEventListener('mouseenter', function () { show(k); });
      a.addEventListener('focus', function () { held = true; show(k); });
      a.addEventListener('blur', function () { held = false; });
    });
    if ('IntersectionObserver' in window) new IntersectionObserver(function (e) { inView = e[0].isIntersecting; }).observe(stage);
    setInterval(function () { if (playing && !held && inView && !document.hidden) go(1); }, 3200);
  }

  /* ---------- specialist services train ---------- */
  var track = $('#train-track');
  if (track) {
    var run = track.querySelector('.train-run'), tBtn = $('#train-play');
    // Keep a slow, constant speed (about 30 px per second) whatever the train length.
    var pace = function () {
      var copy = run.scrollWidth / 2, dur = Math.max(40, Math.round(copy / 30));
      run.style.setProperty('--train-dur', dur + 's');
      // Begin with the second locomotive about a quarter of the way in, so visitors see the engine first.
      var lead = Math.max(0, copy - track.clientWidth * 0.22);
      run.style.animationDelay = (-(lead / copy) * dur).toFixed(2) + 's';
    };
    pace(); addEventListener('resize', pace);
    var setTrain = function (moving) {
      track.classList.toggle('paused', !moving);
      tBtn.textContent = moving ? 'Pause' : 'Play';
      tBtn.setAttribute('aria-pressed', String(!moving));
      tBtn.setAttribute('aria-label', moving ? 'Pause the train' : 'Play the train');
    };
    if (reduce) { tBtn.hidden = true; } else { setTrain(true); tBtn.addEventListener('click', function () { setTrain(track.classList.contains('paused')); }); }
  }

  /* ---------- lightbox ---------- */
  function lightbox(items, start, opener) {
    var idx = start || 0;
    var d = document.createElement('div');
    d.className = 'lb'; d.setAttribute('role', 'dialog'); d.setAttribute('aria-modal', 'true'); d.setAttribute('aria-label', 'Image viewer');
    d.innerHTML = '<img alt=""><p></p><button type="button" class="x" aria-label="Close">&times;</button>' +
      (items.length > 1 ? '<button type="button" class="nv prev" aria-label="Previous image">&larr;</button><button type="button" class="nv next" aria-label="Next image">&rarr;</button>' : '');
    var im = d.querySelector('img'), cap = d.querySelector('p');
    function show() { im.src = items[idx].src; im.alt = items[idx].alt || ''; cap.textContent = items[idx].alt || ''; }
    function close() { d.remove(); document.removeEventListener('keydown', key); document.body.style.overflow = ''; if (opener) opener.focus(); }
    function go(k) { idx = (idx + k + items.length) % items.length; show(); }
    function key(e) {
      if (e.key === 'Escape') close();
      else if (e.key === 'ArrowRight' && items.length > 1) go(1);
      else if (e.key === 'ArrowLeft' && items.length > 1) go(-1);
      else if (e.key === 'Tab') { var b = $$('button', d), i = b.indexOf(document.activeElement); e.preventDefault(); b[(i + (e.shiftKey ? -1 : 1) + b.length) % b.length].focus(); }
    }
    d.addEventListener('click', function (e) {
      if (e.target.classList.contains('prev')) return go(-1);
      if (e.target.classList.contains('next')) return go(1);
      if (e.target === d || e.target.classList.contains('x')) close();
    });
    document.addEventListener('keydown', key);
    document.body.appendChild(d); document.body.style.overflow = 'hidden';
    show(); d.querySelector('.x').focus();
  }
  window.__lightbox = function (src, alt) { lightbox([{ src: src, alt: alt }], 0, document.activeElement); };
  var groups = {};
  $$('[data-full]').forEach(function (b) {
    var g = b.getAttribute('data-group') || ('_' + Math.random());
    (groups[g] = groups[g] || []).push(b);
  });
  Object.keys(groups).forEach(function (g) {
    var list = groups[g];
    var items = list.map(function (b) { var i = b.querySelector('img'); return { src: b.getAttribute('data-full'), alt: i ? i.alt : '' }; });
    list.forEach(function (b, i) { b.addEventListener('click', function () { lightbox(items, i, b); }); });
  });

  /* ---------- copy buttons ---------- */
  $$('[data-copy]').forEach(function (b) {
    b.addEventListener('click', function () {
      var t = b.getAttribute('data-copy'), label = b.textContent;
      var done = function (ok) { b.textContent = ok ? 'Copied' : 'Select and copy'; setTimeout(function () { b.textContent = label; }, 1600); };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(t).then(function () { done(true); }, function () { done(false); });
      else done(false);
    });
  });

  /* ---------- forms ---------- */
  var emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  function setErr(input, msg) {
    var box = document.getElementById(input.id + '-err');
    input.setAttribute('aria-invalid', msg ? 'true' : 'false');
    if (box) box.textContent = msg || '';
  }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  $$('form[data-form]').forEach(function (form) {
    var status = form.querySelector('.form-status');
    var kind = form.getAttribute('data-form');
    var endpoint = (CFG.forms && (kind === 'careers' ? (CFG.forms.careersEndpoint || CFG.forms.endpoint) : CFG.forms.endpoint)) || '';
    var to = (CFG.forms && CFG.forms.recipientEmail) || (CFG.contact && CFG.contact.email) || '';
    form.addEventListener('input', function (e) { if (e.target.getAttribute('aria-invalid') === 'true') validate(e.target); });
    function validate(el) {
      var v = (el.value || '').trim(), msg = '';
      if (el.required && !v) msg = 'Please fill in ' + (el.getAttribute('data-label') || 'this field').toLowerCase() + '.';
      else if (el.type === 'email' && v && !emailRe.test(v)) msg = 'Enter an email address like name@company.com.';
      else if (el.type === 'tel' && v && v.replace(/\D/g, '').length < 10) msg = 'Enter a phone number with at least 10 digits.';
      setErr(el, msg); return !msg;
    }
    function summary() {
      var lines = [];
      $$('input,textarea,select', form).forEach(function (el) {
        if (!el.name || el.type === 'hidden' || el.classList.contains('hp-in') || !el.value.trim()) return;
        lines.push((el.getAttribute('data-label') || el.name) + ': ' + el.value.trim());
      });
      return lines.join('\n');
    }
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var fields = $$('input,textarea,select', form).filter(function (el) { return el.name && el.type !== 'hidden' && !el.classList.contains('hp-in'); });
      var bad = fields.filter(function (el) { return !validate(el); });
      if (bad.length) { status.className = 'form-status bad'; status.textContent = 'Please fix the highlighted ' + (bad.length > 1 ? 'fields' : 'field') + '.'; bad[0].focus(); return; }
      var hp = form.querySelector('.hp-in'); if (hp && hp.value) return;
      var subject = form.getAttribute('data-subject') || 'Website enquiry';
      if (!endpoint) {
        var body = summary();
        var mail = 'mailto:' + to + '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(body);
        status.className = 'form-status warn';
        status.innerHTML = '<b>Your message has not been sent.</b> Online form sending is not connected on this website yet. ' +
          'Please email <b>' + esc(to) + '</b> or call <b>' + esc((CFG.contact && CFG.contact.phoneDisplay) || '') + '</b>. ' +
          'You can open an email draft with your details or copy them below.' +
          '<span class="row"><a class="btn sm p" href="' + esc(mail) + '">Open email draft</a><button type="button" class="btn sm g" data-cp>Copy my details</button></span>';
        var cp = status.querySelector('[data-cp]');
        cp.addEventListener('click', function () {
          var ok = function () { cp.textContent = 'Copied'; };
          if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText('To: ' + to + '\nSubject: ' + subject + '\n\n' + body).then(ok, function () { cp.textContent = 'Copy failed'; });
        });
        status.setAttribute('tabindex', '-1'); status.focus();
        return;
      }
      var btn = form.querySelector('[type=submit]'), label = btn.textContent;
      btn.disabled = true; btn.textContent = 'Sending…';
      status.className = 'form-status'; status.textContent = '';
      var fd = new FormData(form); fd.append('_subject', subject); fd.append('page', location.pathname);
      fetch(endpoint, { method: 'POST', body: fd, headers: { Accept: 'application/json' } })
        .then(function (r) {
          if (!r.ok) throw new Error('HTTP ' + r.status);
          var name = (form.querySelector('[name=name]') || {}).value || '';
          status.className = 'form-status ok';
          status.textContent = 'Thanks' + (name ? ', ' + name.trim().split(' ')[0] : '') + '. Your message was sent to our team.';
          form.reset();
        })
        .catch(function (err) {
          status.className = 'form-status bad';
          status.innerHTML = 'We could not send your message (' + esc(err.message) + '). Please email <b>' + esc(to) + '</b> instead.';
        })
        .then(function () { btn.disabled = false; btn.textContent = label; status.setAttribute('tabindex', '-1'); status.focus(); });
    });
  });
})();

/* Credtech Solutions: one interactive set piece per page (markup in src/templates/fun.mjs). */
(function () {
  'use strict';
  var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return [].slice.call((r || document).querySelectorAll(s)); };
  var clamp = function (v, a, b) { return Math.max(a, Math.min(b, v)); };
  var hasIO = 'IntersectionObserver' in window;
  // Run fn once when el first scrolls into view (or straight away without IntersectionObserver).
  var onView = function (el, fn, margin) {
    if (!hasIO) { fn(); return; }
    var io = new IntersectionObserver(function (es) { if (es[0].isIntersecting) { io.disconnect(); fn(); } }, { rootMargin: margin || '0px 0px -15% 0px' });
    io.observe(el);
  };
  // Track whether el is on screen, so off-screen loops can rest.
  var watch = function (el, cb) {
    if (!hasIO) { cb(true); return; }
    new IntersectionObserver(function (es) { cb(es[0].isIntersecting); }).observe(el);
  };
  // rAF-throttled scroll and resize listener.
  var onScroll = function (fn) {
    var queued = false;
    var tick = function () { queued = false; fn(); };
    var q = function () { if (!queued) { queued = true; requestAnimationFrame(tick); } };
    addEventListener('scroll', q, { passive: true }); addEventListener('resize', q); fn();
  };
  var smooth = reduce ? 'auto' : 'smooth';

  /* ---------- Case studies + About: odometers ---------- */
  $$('.odo').forEach(function (o) { if (reduce) o.classList.add('on'); else onView(o, function () { o.classList.add('on'); }); });

  /* ---------- About: elevator ---------- */
  var car = $('#lift-car');
  if (car) {
    var liftCards = $$('.lift-card'), levels = $$('.lift-levels .lv').reverse(), liftNo = $('#lift-no'), floor = -1, doorT;
    var goFloor = function (f) {
      if (f === floor) return;
      floor = f;
      car.classList.remove('open');
      car.style.setProperty('--floor', f);
      liftNo.textContent = (f + 1 < 10 ? '0' : '') + (f + 1);
      levels.forEach(function (l, k) { l.classList.toggle('on', k === f); });
      liftCards.forEach(function (c, k) { c.classList.toggle('on', k === f); });
      clearTimeout(doorT); doorT = setTimeout(function () { car.classList.add('open'); }, reduce ? 0 : 1100);
    };
    onScroll(function () {
      var mid = innerHeight * 0.5, f = 0;
      liftCards.forEach(function (c, k) { if (c.getBoundingClientRect().top < mid) f = k; });
      goFloor(f);
    });
  }

  /* ---------- Service pages: metro line ---------- */
  var metro = $('#metro');
  if (metro) {
    var stops = $$('a[data-i]', metro), mCar = $('.metro-car', metro), mOl = $('ol', metro), active = -1;
    var targets = stops.map(function (a) { return document.getElementById(a.getAttribute('href').slice(1)); });
    var place = function () {
      if (active < 0) return;
      var dot = stops[active].querySelector('i'), r = dot.getBoundingClientRect(), m = metro.getBoundingClientRect();
      var x = r.left - m.left - metro.clientLeft + r.width / 2 - mCar.offsetWidth / 2 - mCar.offsetLeft;
      var y = r.top - m.top - metro.clientTop + r.height / 2 - mCar.offsetHeight / 2 - mCar.offsetTop;
      mCar.style.setProperty('--cx', x.toFixed(1) + 'px'); mCar.style.setProperty('--cy', y.toFixed(1) + 'px');
    };
    var setStop = function (i) {
      if (i === active) return;
      active = i;
      stops.forEach(function (a, k) {
        a.classList.toggle('on', k === i); a.classList.toggle('done', k < i);
        if (k === i) a.setAttribute('aria-current', 'step'); else a.removeAttribute('aria-current');
      });
      // In the horizontal (tablet and phone) layout, keep the active stop visible inside the line.
      if (mOl.scrollWidth > mOl.clientWidth + 2) {
        var a = stops[i], want = a.offsetLeft - (mOl.clientWidth - a.offsetWidth) / 2;
        mOl.scrollTo({ left: clamp(want, 0, mOl.scrollWidth - mOl.clientWidth), behavior: smooth });
      }
      place();
    };
    mOl.addEventListener('scroll', place, { passive: true });
    onScroll(function () {
      var line = innerHeight * 0.38, i = 0;
      targets.forEach(function (t, k) { if (t && t.getBoundingClientRect().top < line) i = k; });
      setStop(i); place();
    });
  }

  /* ---------- Campaigns: billboard tower ---------- */
  var ring = $('#pt-ring');
  if (ring) {
    var ptStage = $('#pt-stage'), faces = $$('.pt-face', ring), M = faces.length, stepA = 360 / M;
    var ptTitle = $('#pt-title'), ptChip = $('#pt-chip'), ptPlay = $('#pt-play');
    var ang = 0, vel = 0, target = null, auto = !reduce, hover = false, seen = true, drag = null, front = -1, resumeAt = 0, last = 0;
    var render = function () {
      ring.style.setProperty('--a', ang.toFixed(2) + 'deg');
      var f = ((Math.round(-ang / stepA) % M) + M) % M;
      if (f !== front) {
        front = f;
        faces.forEach(function (el, k) { el.classList.toggle('front', k === f); });
        ptTitle.textContent = faces[f].getAttribute('data-title');
        ptChip.textContent = faces[f].getAttribute('data-chip');
      }
    };
    var snapTo = function (a) { target = a; vel = 0; resumeAt = performance.now() + 3500; if (reduce) { ang = a; target = null; render(); } };
    var nearest = function () { return Math.round(ang / stepA) * stepA; };
    var setPt = function (on) {
      auto = on;
      ptPlay.textContent = on ? 'Pause' : 'Play';
      ptPlay.setAttribute('aria-pressed', String(!on));
      ptPlay.setAttribute('aria-label', on ? 'Pause the tower' : 'Play the tower');
    };
    setPt(auto);
    ptPlay.addEventListener('click', function () { setPt(!auto); if (!auto) snapTo(nearest()); });
    $('#pt-prev').addEventListener('click', function () { snapTo(nearest() + stepA); });
    $('#pt-next').addEventListener('click', function () { snapTo(nearest() - stepA); });
    ptStage.addEventListener('mouseenter', function () { hover = true; });
    ptStage.addEventListener('mouseleave', function () { hover = false; });
    faces.forEach(function (el, k) {
      // Keyboard: focusing a poster turns it to the front.
      el.addEventListener('focus', function () {
        var want = -k * stepA, turns = Math.round((ang - want) / 360);
        snapTo(want + turns * 360);
      });
    });
    ptStage.addEventListener('pointerdown', function (e) {
      if (e.button !== 0) return;
      drag = { x: e.clientX, a: ang, t: performance.now(), moved: false, lastX: e.clientX };
      target = null; vel = 0;
    });
    addEventListener('pointermove', function (e) {
      if (!drag) return;
      var dx = e.clientX - drag.x;
      if (!drag.moved && Math.abs(dx) > 6) { drag.moved = true; ptStage.classList.add('drag'); try { ptStage.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ } }
      if (!drag.moved) return;
      var now = performance.now(), dt = Math.max(1, now - drag.t);
      vel = ((e.clientX - drag.lastX) * 0.32) / dt * 16;
      drag.t = now; drag.lastX = e.clientX;
      ang = drag.a + dx * 0.32; render();
    });
    var endDrag = function () {
      if (!drag) return;
      var moved = drag.moved; drag = null; ptStage.classList.remove('drag');
      if (moved) { resumeAt = performance.now() + 3500; if (reduce || Math.abs(vel) < 0.4) snapTo(nearest()); }
      ptStage.dataset.moved = moved ? '1' : '';
    };
    addEventListener('pointerup', endDrag); addEventListener('pointercancel', endDrag);
    // A drag should not count as a click on the poster under the pointer.
    ptStage.addEventListener('click', function (e) { if (ptStage.dataset.moved) { e.preventDefault(); ptStage.dataset.moved = ''; } }, true);
    watch(ptStage, function (v) { seen = v; });
    var loop = function (now) {
      var dt = Math.min(48, now - (last || now)); last = now;
      if (seen && !document.hidden && !drag) {
        if (target !== null) {
          ang += (target - ang) * Math.min(1, dt * 0.009);
          if (Math.abs(target - ang) < 0.05) { ang = target; target = null; }
        } else if (Math.abs(vel) > 0.02) {
          ang += vel * dt / 16; vel *= Math.pow(0.94, dt / 16);
          if (Math.abs(vel) <= 0.4) { vel = 0; snapTo(nearest()); }
        } else if (auto && !hover && now > resumeAt) {
          ang -= dt * 0.009; // about 9 degrees a second
        }
        render();
      }
      requestAnimationFrame(loop);
    };
    render();
    requestAnimationFrame(loop);
  }

  /* ---------- Clients: logo orbit ---------- */
  var orbit = $('#orbit');
  if (orbit) {
    var oScale = $('.orbit-scale', orbit), oItems = $$('.orbit-item', orbit), oAng = 0, oHold = false, oSeen = true, oLast = 0;
    var oCompact = false;
    var oFit = function () {
      // Narrow columns use smaller rings so the logos stay a readable size.
      oCompact = orbit.clientWidth < 560;
      orbit.classList.toggle('compact', oCompact);
      var s = Math.min(1, orbit.clientWidth / (oCompact ? 490 : 700));
      oScale.style.setProperty('--s', s.toFixed(3)); oScale.style.height = Math.round((oCompact ? 330 : 440) * s) + 'px';
    };
    var oRender = function () {
      oItems.forEach(function (el) {
        var r = +el.getAttribute('data-ring'), k = +el.getAttribute('data-k'), n = +el.getAttribute('data-n');
        var R = oCompact ? (r === 1 ? 125 : 195) : (r === 1 ? 180 : 280), t = (k / n) * 360 + (r === 2 ? 180 / n : 0) + (r === 1 ? oAng : oAng * 0.6);
        el.style.transform = 'rotateX(66deg) rotateZ(' + t.toFixed(2) + 'deg) translateX(' + R + 'px) rotateZ(' + (-t).toFixed(2) + 'deg) rotateX(-66deg)';
        // Logos on the far side of the planet fade back a little.
        el.style.opacity = (0.5 + 0.5 * (Math.sin(t * Math.PI / 180) + 1) / 2).toFixed(3);
      });
    };
    oFit(); addEventListener('resize', function () { oFit(); oRender(); }); oRender();
    orbit.addEventListener('mouseenter', function () { oHold = true; });
    orbit.addEventListener('mouseleave', function () { oHold = false; });
    orbit.addEventListener('focusin', function () { oHold = true; });
    orbit.addEventListener('focusout', function () { oHold = false; });
    watch(orbit, function (v) { oSeen = v; });
    if (!reduce) {
      var oLoop = function (now) {
        var dt = Math.min(48, now - (oLast || now)); oLast = now;
        if (oSeen && !oHold && !document.hidden) { oAng += dt * 0.012; oRender(); }
        requestAnimationFrame(oLoop);
      };
      requestAnimationFrame(oLoop);
    }
  }

  /* ---------- Plans: skyline ---------- */
  var sky = $('#sky');
  if (sky) {
    if (reduce) sky.classList.add('built'); else onView(sky, function () { sky.classList.add('built'); }, '0px');
    $$('.sky-tower', sky).forEach(function (b) {
      b.addEventListener('click', function () {
        var id = b.getAttribute('data-plan'), el = document.getElementById(id);
        if (!el) return;
        el.scrollIntoView({ behavior: smooth, block: 'center' });
        if (window.__flash) window.__flash('#' + id);
      });
    });
  }

  /* ---------- Blog posts: reading rocket ---------- */
  var rocket = $('#rocket'), postBody = $('#post-body');
  if (rocket && postBody) {
    var pct = $('.rk-pct', rocket);
    onScroll(function () {
      var r = postBody.getBoundingClientRect();
      var p = clamp((innerHeight * 0.8 - r.top) / Math.max(1, r.height), 0, 1);
      if (innerHeight + scrollY >= document.documentElement.scrollHeight - 4) p = 1;
      rocket.style.setProperty('--p', p.toFixed(4));
      pct.textContent = Math.round(p * 100) + '%';
      rocket.classList.toggle('landed', p >= 0.995);
    });
  }

  /* ---------- Contact: signal tower ---------- */
  var signal = $('#signal'), audit = $('#audit');
  if (signal && audit) {
    var bars = $$('.sig-bars i', signal), sigText = $('#sig-text'), sigStage = $('.sig-stage', signal), lastN = 0;
    var names = ['name', 'email', 'phone', 'company', 'message'];
    var words = ['Fill in the form to boost the signal.', 'Signal found. Keep going.', 'Signal getting stronger.', 'Strong signal.', 'Almost there.', 'Full signal. Ready to send.'];
    var ok = function (el) {
      if (!el) return false;
      var v = el.value.trim();
      if (!v) return false;
      if (el.type === 'email') return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
      if (el.type === 'tel') return v.replace(/\D/g, '').length >= 7;
      return true;
    };
    var burst = function () {
      if (reduce) return;
      var s = document.createElement('span'); s.className = 'sig-ring burst'; s.setAttribute('aria-hidden', 'true');
      sigStage.appendChild(s);
      setTimeout(function () { s.remove(); }, 1300);
    };
    var measure = function () {
      var n = names.filter(function (nm) { return ok(audit.querySelector('[name="' + nm + '"]')); }).length;
      bars.forEach(function (b, k) { b.classList.toggle('on', k < n); });
      if (n !== lastN) { sigText.textContent = words[n]; if (n > lastN) burst(); lastN = n; }
    };
    audit.addEventListener('input', measure); audit.addEventListener('change', measure);
    measure();
  }

  /* ---------- Schedule: split-flap board ---------- */
  var board = $('#board');
  if (board) {
    var CH = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    var clock = $('#bd-clock');
    var tickClock = function () {
      var d = new Date();
      clock.textContent = (d.getHours() < 10 ? '0' : '') + d.getHours() + ':' + (d.getMinutes() < 10 ? '0' : '') + d.getMinutes();
    };
    tickClock(); setInterval(tickClock, 15000);
    var setCell = function (cell, c) { cell.textContent = c === ' ' ? ' ' : c; };
    // Flip one cell through a few random letters before it lands on its character.
    var flipTo = function (cell, c, delay) {
      if (reduce) { setCell(cell, c); return; }
      var n = 4 + Math.floor(Math.random() * 6), k = 0;
      setTimeout(function step() {
        cell.classList.remove('flip'); void cell.offsetWidth; cell.classList.add('flip');
        if (k++ < n) { setCell(cell, CH[Math.floor(Math.random() * CH.length)]); setTimeout(step, 70); }
        else { setCell(cell, c); setTimeout(function () { cell.classList.remove('flip'); }, 100); }
      }, delay);
    };
    var writeRow = function (cells, text, base) {
      var s = text.toUpperCase();
      cells.forEach(function (cell, i) { flipTo(cell, s[i] || ' ', (base || 0) + i * 35); });
    };
    var allRows = $$('.bd-rows li', board);
    onView(board, function () {
      allRows.forEach(function (li, r) {
        $$('.fl', li).forEach(function (cell, i) { flipTo(cell, cell.getAttribute('data-c'), r * 260 + i * 30); });
      });
    }, '0px');
    var stat = $$('.bd-c2', board).map(function (c) { return { el: c, cells: $$('.fl', c), a: $$('.fl', c).map(function (f) { return f.getAttribute('data-c'); }).join('').trim(), b: c.getAttribute('data-alt'), showB: false }; });
    var bdSeen = true; watch(board, function (v) { bdSeen = v; });
    if (!reduce) setInterval(function () {
      if (!bdSeen || document.hidden) return;
      stat.forEach(function (s, r) { if (s.b && s.b.toUpperCase() !== s.a.toUpperCase()) { s.showB = !s.showB; writeRow(s.cells, s.showB ? s.b : s.a, r * 220); } });
    }, 6000);
  }

  /* ---------- Careers: balloons ---------- */
  var balloonsBox = $('#balloons');
  if (balloonsBox) {
    var roleSel = $('#apply-role'), blNote = $('#bl-note'), applyForm = $('#apply');
    var bls = $$('.balloon', balloonsBox);
    bls.forEach(function (b) {
      b.addEventListener('click', function () {
        var role = b.getAttribute('data-role');
        bls.forEach(function (o) { o.classList.toggle('pick', o === b); });
        if (roleSel) { roleSel.value = role; roleSel.dispatchEvent(new Event('change', { bubbles: true })); }
        blNote.textContent = role + ' chosen. The form below is ready for you.';
        if (!reduce) { b.classList.add('lift'); setTimeout(function () { b.classList.remove('lift'); }, 2600); }
        if (applyForm) setTimeout(function () {
          applyForm.scrollIntoView({ behavior: smooth, block: 'start' });
          var first = applyForm.querySelector('[name="name"]'); if (first) first.focus({ preventScroll: true });
        }, reduce ? 0 : 900);
      });
    });
    if (roleSel) roleSel.addEventListener('change', function () { bls.forEach(function (o) { o.classList.toggle('pick', o.getAttribute('data-role') === roleSel.value); }); });
  }

  /* ---------- Privacy: vault dial ---------- */
  var dial = $('#vt-dial'), policy = $('#policy-body');
  if (dial && policy) {
    onScroll(function () {
      var r = policy.getBoundingClientRect();
      var p = clamp((innerHeight * 0.8 - r.top) / Math.max(1, r.height), 0, 1);
      dial.style.setProperty('--rot', (p * 720).toFixed(1) + 'deg');
    });
  }
})();
